<div class="alert alert-danger" role="alert">
  No such view file - <?= $name; ?>
</div>