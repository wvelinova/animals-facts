<?php

//src/Exception/InvalidRespomseBodyException.php

namespace App\Exception;
use Exception;

/**
 * Description of InvalidResponseBodyException
 *
 * @author Viktoriya
 */
class InvalidResponseBodyException extends Exception {
    //put your code here
}
