<?php

//src/Exception/InvalidFactTypeException.php

namespace App\Exception;
use Exception;

/**
 * Description of InvalidFactTypeException
 *
 * @author Viktoriya
 */
class InvalidFactTypeException extends Exception{
    //put your code here
}
