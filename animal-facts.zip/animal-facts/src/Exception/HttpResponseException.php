<?php

// src/Excetion/HttpResponseException.php

namespace App\Exception;
use Exception;

/**
 * Description of HttpResponseException
 *
 * @author Viktoriya
 */
class HttpResponseException extends Exception {
    //put your code here
}
