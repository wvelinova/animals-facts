<?php

//src/Exception/InvalidCollectionObjectException.php

namespace App\Exception;
use Exception;

/**
 * Description of InvalidCollectionObjectException
 *
 * @author Viktoriya
 */
class InvalidCollectionObjectException extends Exception {
    //put your code here
}
