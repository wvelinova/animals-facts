<?php

//src/Exception/InvalidUserNameException.php

namespace App\Exception;
use Exception;

/**
 * Description of InvalidUserNameException
 *
 * @author Viktoriya
 */
class InvalidUserNameException extends Exception {
    //put your code here
}
