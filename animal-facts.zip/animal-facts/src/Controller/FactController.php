<?php

namespace App\Controller;

use App\Repository\FactRepository;
use App\View\View;

/**
 * Description of FactController
 *
 * @author Viktoriya
 */
class FactController {
    protected FactRepository $repository;
    protected View $view;
    
    public function __construct(FactRepository $repository, View $view): mixed {
        
    }
    
    public function list(int $amount, string $type):string{
        
    }
     
    public function single(string $id): string{
        
    }
}
