<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace App\Controller;
use App\View\View;

/**
 * Description of FactControllerFactory
 *
 * @author Viktoriya
 */
class FactControllerFactory {
    
   public static function create(View $view){
       return $view;
   }
}
