<?php


namespace App\Model;

/**
 * Description of User
 *
 * @author Viktoriya
 */
class User {
    protected string $id;
    protected array $name;
    protected string $photo;
    
    public function __construct (string $id, string $photo, array $name) : mixed{
        $this->id = $id;
        $this->photo = $photo;
        $this->name = $name;       
}
public function getFirstName():string {
    
}
public function getLastName():string{
    
}
public function getFullName():string{
    
}
public function getId(): string {
    return $this->id;
}

public function getName(): array {
    return $this->name;
}

public function getPhoto(): string {
    return $this->photo;
}

public function setId(string $id) {
    $this->id = $id;
    return $this;
}

public function setName(array $name) {
    $this->name = $name;
    return $this;
}

public function setPhoto(string $photo) {
    $this->photo = $photo;
    return $this;
}


}
