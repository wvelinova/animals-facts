<?php

//src/Model/FactCollection.php

namespace App\Model;

/**
 * Description of FactColection
 *
 * @author Viktoriya
 */
class FactCollection {
    
  public function offsetSet(mixed $index, mixed $newval): void{
      
  }
  
  protected function ensureFactObject(object $object):void{
      
  }
}
