<?php

//src/Model/Status.php

namespace App\Model;

/**
 * Description of Status
 *
 * @author Viktoriya
 */
class Status {
    protected bool $verified;
    protected int $sentCount;
   
 public function  __construct(bool $verified = null,int $sentCount = null) : mixed{
     
    }
    
    public function getVerified(): bool {
        return $this->verified;
    }

    public function getSentCount(): int {
        return $this->sentCount;
    }

    public function setVerified(bool $verified) {
        $this->verified = $verified;
        
        return $this;
    }

    public function setSentCount(int $sentCount) {
        $this->sentCount = $sentCount;
        return $this;
    }


}
    
  

