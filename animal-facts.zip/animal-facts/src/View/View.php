<?php

namespace App\View;


/**
 * Description of View
 *
 * @author Viktoriya
 */
class View {
    protected string $viewDirectory;
    
    public function __construct(string $viewDirectory){
        $this->viewDirectory = $viewDirectory;
        return $viewDirectory;
    }  

    public function render(string $viewName, array $viewModel) : string{
        
        if(!include($viewName))
        {
            
            render('./views/error/no_view.php', $viewModel);
        
        }
  
        ob_start();
        include($viewName);
        $viewModel=ob_get_contents(); 
        ob_end_clean();
        return extract($viewModel);
        
    }
    
}
