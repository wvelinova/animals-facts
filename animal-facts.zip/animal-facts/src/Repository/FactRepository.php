<?php

namespace App\Reposiroty;

use App\Model\Fact;
use App\Model\FactColection;
use Psr\Http\Client\ClientInterface;
use Psr\Http\Message\StreamInterface;
use Psr\Http\Message\RequestInterface;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Request;

/**
 * Description of FactRepository
 *
 * @author Viktoriya
 */
class FactRepository {
    protected string $baseUrl;
    protected ClientInterface $httpClient;
    
    public function __construct(ClientInterface $httpClient, string $baseUrl){
        
        $request = new Request("HTTP", $baseUrl);
        
        $response = $httpClient->sendRequest($request);
        
    }
public function getFact (string $id) {
    
}
public function getRandomList(int $amount = 1,string $animalType = 'cat') {
    
}
protected function createFact(stdClass $object) : Fact {
    
}
protected function createRequest(string $endpoint, array $params = [] ){
    
}
protected function decodeResponseBody(StreamInterface $body) {
    
}
protected function ensureHttpResponseIsOK(ResponseInterface $response){
    
}
}
