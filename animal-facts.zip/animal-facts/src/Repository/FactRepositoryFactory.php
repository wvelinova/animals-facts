<?php
namespace App\Repository;

use App\Repository\FactRepository;
/**
 * Description of FactRepositoryFactory
 *
 * @author Viktoriya
 */
class FactRepositoryFactory {
    
    public static function create ():FactRepository{
        
    }
}
